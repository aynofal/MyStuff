/**
 * Created by Ahmed on 4/25/2016.
 */
"use strict";

function login(){
    let loginID = $('#loginID').val();
    let loginPassword = $('#loginPassword').val();

    console.log('user entered: ' + loginID + " " + loginPassword );
}